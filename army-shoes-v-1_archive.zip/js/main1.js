$(document).ready(function() {

    $('[data-href]').on('click', function() {
        $('html, body').animate({
            scrollTop: $($(this).data('href')).offset().top
        }, 800)
    })


    $('.owl-carousel').owlCarousel({ loop: true, margin: 10, nav: false, dots: true, autoplay: false, autoplayTimeout: 3000, smartSpeed: 850, autoplayHoverPause: true, animate: true, responsive: { 0: { items: 1 } } })
});